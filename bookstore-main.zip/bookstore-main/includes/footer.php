
</div>
       
       <footer class="bg-dark text-white text-center text-lg-start" style="margin-top: 40px">
       <!-- Grid container -->
       <div class="container p-4">
           <!--Grid row-->
           <div class="row">
           <!--Grid column-->
           <div class="col-lg-6 col-md-12 mb-4 mb-md-0">
               <h5 class="text-uppercase">Bookstore</h5>

               <p>
               Lorem ipsum dolor sit amet consectetur, adipisicing elit. Iste atque ea quis
               molestias. Fugiat pariatur maxime quis culpa corporis vitae repudiandae aliquam
               voluptatem veniam, est atque cumque eum delectus sint!
               </p>
           </div>
           <!--Grid column-->

           <!--Grid column-->
           <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
               <h5 class="text-uppercase" style="text-decoration: none;">Links</h5>

               <ul class="list-unstyled mb-0" style="text-decoration: none;">
               <li>
                   <a href="#!" class="text-white" style="text-decoration: none;">Careers</a>
               </li>
               <li>
                   <a href="#!" class="text-white" style="text-decoration: none;">Support</a>
               </li>
               <li>
                   <a href="#!" class="text-white" style="text-decoration: none;">Blog</a>
               </li>
               <li>
                   <a href="#!" class="text-white" style="text-decoration: none;">Investors</a>
               </li>
               </ul>
           </div>
           <!--Grid column-->

           <!--Grid column-->
           <div class="col-lg-3 col-md-6 mb-4 mb-md-0">
               <h5 class="text-uppercase mb-0" style="text-decoration: none;">Links</h5>

               <ul class="list-unstyled">
               <li>
                   <a href="#!" class="text-white" style="text-decoration: none;">Terms</a>
               </li>
               <li>
                   <a href="#!" class="text-white" style="text-decoration: none;">Privacy Policy</a>
               </li>
               <li>
                   <a href="#!" class="text-white" style="text-decoration: none;">Blog</a>
               </li>
               <li>
                   <a href="#!" class="text-white" style="text-decoration: none;">Sitemap</a>
               </li>
               </ul>
           </div>
           <!--Grid column-->
           </div>
           <!--Grid row-->
       </div>
       <!-- Grid container -->

       <!-- Copyright -->
       <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
           © 2024 Copyright:
           <a class="text-white" href="https://mdbootstrap.com/">MDBootstrap.com</a>
       </div>
       <!-- Copyright -->
       </footer>

       <script src="https://code.jquery.com/jquery-2.2.4.js" integrity="" crossorigin="anonymous"></script>
       <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="" crossorigin="anonymous"></script>
       <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="" crossorigin="anonymous"></script>
 </body>

</html>